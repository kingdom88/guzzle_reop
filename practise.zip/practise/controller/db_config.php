<?php
	define('DB_SERVER', 'localhost');
	define('DB_USERNAME', 'root');
	define('DB_PASSWORD', 'winxclub88');
	define('DB_DATABASE', 'oop');
?>