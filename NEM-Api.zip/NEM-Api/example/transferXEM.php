<?php

/* 
 * NEMを送金するサンプルプログラムです。
 * 動作確認はTestnetでお願いします。
 * This sample program is transfer XEM.
 * Please test on testnet!
 */


    require_once '../NEMApiLibrary.php';
    
    
    $net = 'testnet';
    $NEMpubkey = '1837596f725e10486de69f047d2273447652150cf684d64ee742bee033bc6fae';
    $NEMprikey = 'fbeb13fa253b9962c91b7276e3b60b4bbe9d117d5b8add3297e6091de44336b6';
    $baseurl = 'http://localhost:7890';
    $address = 'TD6GI5SVOFJVTDUPKYOAIJOUOGY3UIYA6ZJIMZPY'; // recipient
    
    
    $nem = new TransactionBuilder($net);
    $nem->setting($NEMpubkey, $NEMprikey, $baseurl);
    $nem->ImportAddr($address);
    $nem->amount = 0.1; // 12XEM
    $nem->message = 'I love nem.';
  //$nem->payload = 'fe123456789abcdef'; //変換されずにHEXのまま送られます. If you want to send raw hex code ,use $nem->payload
    $fee = $nem->EstimateFee();
    $reslt = $nem->SendNEMver1();
    $anal = $nem->analysis($reslt);
    
    
    echo '<P>','Fee is ',$fee,'<BR>';
    if($anal['status']){
        echo 'TXID is ',$anal['txid'],'</P>';
    }else{
        echo "Fail to send.<BR>error message: {$anal['message']}</P>";
    }
    
    
    
